<?php
// Sesuaikan dengan setting MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "penduduk_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Mendapatkan ID dari URL dan memeriksa apakah ada
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = intval($_GET['id']); // Mengkonversi ID ke integer untuk keamanan

    // Query untuk menghapus catatan
    $sql = "DELETE FROM penduduk WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "ID not provided or invalid.";
}

$conn->close();

// Redirect kembali ke halaman utama (index.php) hanya jika penghapusan berhasil
header("Location: index.php");
exit;
